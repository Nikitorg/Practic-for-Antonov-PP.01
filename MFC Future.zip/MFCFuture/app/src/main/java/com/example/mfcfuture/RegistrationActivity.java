package com.example.mfcfuture;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class RegistrationActivity extends AppCompatActivity {

    EditText editFullName, editNumberPhone, editLogin, editPassword, editPasswrod2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        editFullName = findViewById(R.id.editFullName);
        editNumberPhone = findViewById(R.id.editNumberPhone);
        editLogin = findViewById(R.id.editLogin);
        editPassword = findViewById(R.id.editPassword);
        editPasswrod2 = findViewById(R.id.editPassword2);

        Button loginButton = findViewById(R.id.loginButton);
        Button registerButton = findViewById(R.id.registerButton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!(editFullName.getText().toString().isEmpty()
                        || editNumberPhone.getText().toString().isEmpty()
                        || editLogin.getText().toString().isEmpty()
                        || editPassword.getText().toString().isEmpty()
                        || editPasswrod2.getText().toString().isEmpty())) {
                    if(editPassword.getText().toString().equals(editPasswrod2.getText().toString())) {

                        if(editPassword.getText().length() >=4) {
                            User user = new User(editFullName.getText().toString(),
                                    editNumberPhone.getText().toString(),
                                    editLogin.getText().toString(),
                                    editPassword.getText().toString());

                            boolean success = UserManager.register(user);


                        if(success) {
                            Toast.makeText(RegistrationActivity.this,
                                    "Ваш аккаунт успешно создан!",
                                    Toast.LENGTH_SHORT).show();
                            finish();
                        } else{
                            Toast.makeText(RegistrationActivity.this,
                                    "Такой логин уже существует!",
                                    Toast.LENGTH_SHORT).show();
                        }
                        } else {
                            Toast.makeText(RegistrationActivity.this,
                                    "Длинна пароля должна быть не меньше 4 символов!",
                                    Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        Toast.makeText(RegistrationActivity.this,
                                "Пароли не совпадают",
                                Toast.LENGTH_SHORT).show();
                    }
                } else{
                    Toast.makeText(RegistrationActivity.this,
                            "Заполните все поля!",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}