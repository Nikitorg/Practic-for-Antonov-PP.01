package com.example.mfcfuture;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.savedstate.SavedStateRegistry;

public class AutoizationActivity extends AppCompatActivity {

    public static User currentUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_autoization);

        final EditText editLogin = findViewById(R.id.editLogin);
        final EditText editPassword = findViewById(R.id.editPassword);

        Button registerButton = findViewById(R.id.registerButton);
        Button loginButton = findViewById(R.id.loginButton);

        //Регистрация (переход)
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AutoizationActivity.this, RegistrationActivity.class);
                startActivity(intent);
            }
        });

        //Вход (переход)
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String login = editLogin.getText().toString();
                String password = editPassword.getText().toString();

                User users = UserManager.login(editLogin.getText().toString(),
                        editPassword.getText().toString());
                if(users != null) {
                    if (users.getLogin().toString().equals(editLogin.getText().toString()) &&
                            users.getPassword().toString().equals(editPassword.getText().toString())) {
                        Intent intent = new Intent(AutoizationActivity.this, MainMenuActivity.class);
                        startActivity(intent);
                        currentUser = users; //запоминаем текущего пользователя
                        finish();
                    } else {
                        Toast.makeText(AutoizationActivity.this,
                                "Такого пользователя не существует!",
                                Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(AutoizationActivity.this,
                            "Неверный логин или пароль",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
