package com.example.mfcfuture;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SelectTimeActivity extends AppCompatActivity {

    private GridLayout timeGrid;
    private String selectedDate;
    private String selectedFilial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_time);

        TextView informationRecord = findViewById(R.id.informationRecord);

        Button btnBack = findViewById(R.id.btnBack);

        timeGrid = findViewById(R.id.timeGrid);

        selectedDate = getIntent().getStringExtra("date");
        selectedFilial = getIntent().getStringExtra("filial");

        informationRecord.setText(selectedFilial + "\n" + selectedDate);
        hideBusyTimesForSelectedDate();

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        for (int i = 0; i < timeGrid.getChildCount(); i++) {
            View child = timeGrid.getChildAt(i);
            if (child instanceof Button) {
                final Button timeButton = (Button) child;

                timeButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String selectedTime = timeButton.getText().toString();

                        Intent resultIntent = new Intent();
                        resultIntent.putExtra("selectedTime", selectedTime);
                        setResult(RESULT_OK, resultIntent);
                        finish();
                    }
                });
            }
        }
    }

    private void hideBusyTimesForSelectedDate() {
        for (Records record : RecordStorage.recordList) {
            if (record.getDate().equals(selectedDate)
                    && record.getFilial().equals(selectedFilial)) {
                hideTimeButton(record.getTime());
            }
        }
    }

    private void hideTimeButton(String time) {
        for (int i = 0; i < timeGrid.getChildCount(); i++) {
            View child = timeGrid.getChildAt(i);
            if (child instanceof Button) {
                Button btn = (Button) child;
                if (btn.getText().toString().equals(time)) {
                    btn.setVisibility(View.GONE);
                }
            }
        }
    }
}
