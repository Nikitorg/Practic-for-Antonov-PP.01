package com.example.mfcfuture;

import java.sql.Time;

public class Records {
    private String usersLogin;
    private String region;
    private String filial;
    private String service;
    private String date;
    private String time;

    public Records(String usersLogin, String region, String filial, String service, String date, String time) {
        this.usersLogin = usersLogin;
        this.region = region;
        this.filial = filial;
        this.service = service;
        this.date = date;
        this.time = time;
    }

    public String getUsersLogin() {
        return usersLogin;
    }

    public String getRegion() {
        return region;
    }

    public String getFilial() {
        return filial;
    }

    public String getService() {
        return service;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }
}