package com.example.mfcfuture;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class MakeAppointmentActivity extends AppCompatActivity {

    private TextView day, mounth, year;
    private Spinner spinnerRegion, spinnerBranch, spinnerService;
    private Button btnSelectTime, btnBack;
    private String selectedTime = "";
    private static final int REQUEST_SELECT_TIME = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_make_appointment);

        spinnerRegion = findViewById(R.id.spinnerRegion);
        spinnerBranch = findViewById(R.id.spinnerBranch);
        spinnerService = findViewById(R.id.spinnerService);

        Button btnSubmit = findViewById(R.id.btnSubmit);
        btnBack = findViewById(R.id.btnBack);

        btnSelectTime = findViewById(R.id.btnSelectTime);

        LinearLayout dateContainer = findViewById(R.id.dateContainer);
        day = findViewById(R.id.day);
        mounth = findViewById(R.id.mounth);
        year = findViewById(R.id.year);

        dateContainer.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();

            DatePickerDialog dialog = new DatePickerDialog(
                    MakeAppointmentActivity.this,
                    (view, selectedYear, selectedMonth, selectedDay) -> {
                        day.setText(String.format("%02d", selectedDay));
                        mounth.setText(String.format("%02d", selectedMonth + 1));
                        year.setText(String.valueOf(selectedYear));
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );

            dialog.show();
        });

        String[] regions = {"Тверь","Конаково","Ржев","Вышний Волочек","Бежецк","Торжок"};
        String[] branches = {"МФЦ Тверь - Пролетарский","МФЦ Тверь - Московский","МФЦ Конаково","МФЦ Ржев","МФЦ Вышний Волочек"};
        String[] services = {"Паспорт РФ (внутренний)","Заграничный паспорт","Регистрация по месту жительства",
                "Справка о доходах","Выдача ИНН","Регистрация ТС","Водительское удостоверение",
                "Социальные выплаты","Субсидии ЖКХ","Регистрация ИП"};

        spinnerRegion.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, regions));
        spinnerBranch.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, branches));
        spinnerService.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, services));

        btnSelectTime.setOnClickListener(v -> {

            if (day.getText().toString().isEmpty() ||
                    mounth.getText().toString().isEmpty() ||
                    year.getText().toString().isEmpty()) {
                Toast.makeText(MakeAppointmentActivity.this, "Выберите дату", Toast.LENGTH_SHORT).show();
                return;
            }

            String date = day.getText().toString() + "." +
                    mounth.getText().toString() + "." +
                    year.getText().toString();
            String filial = spinnerBranch.getSelectedItem().toString();

            Intent intent = new Intent(MakeAppointmentActivity.this, SelectTimeActivity.class);
            intent.putExtra("date", date);
            intent.putExtra("filial", filial);
            startActivityForResult(intent, REQUEST_SELECT_TIME);

        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveRecord();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_SELECT_TIME && resultCode == RESULT_OK && data != null) {
            selectedTime = data.getStringExtra("selectedTime");
            btnSelectTime.setText("Выбрано: " + selectedTime);
        }
    }

    private void saveRecord() {
        if (selectedTime.isEmpty()) {
            Toast.makeText(this, "Выберите время", Toast.LENGTH_SHORT).show();
            return;
        }

        if (day.getText().toString().isEmpty() ||
                mounth.getText().toString().isEmpty() ||
                year.getText().toString().isEmpty()) {
            Toast.makeText(this, "Введите дату", Toast.LENGTH_SHORT).show();
            return;
        }

        String usersLogin = AutoizationActivity.currentUser.getLogin();
        String region = spinnerRegion.getSelectedItem().toString();
        String filial = spinnerBranch.getSelectedItem().toString();
        String service = spinnerService.getSelectedItem().toString();
        String date = day.getText().toString() + "." + mounth.getText().toString() + "." + year.getText().toString();

        Records record = new Records(usersLogin, region, filial, service, date, selectedTime);

        RecordStorage.recordList.add(record);

        Toast.makeText(this, "Вы успешно записались", Toast.LENGTH_LONG).show();
        finish();
    }
}
