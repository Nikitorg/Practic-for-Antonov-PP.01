package com.example.mfcfuture;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecordsAdapter extends RecyclerView.Adapter<RecordsAdapter.ViewHolder> {

    private ArrayList<Records> records;

    public RecordsAdapter(ArrayList<Records> records) {
        this.records = records;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView date, time, filial, service;

        ViewHolder(View itemView) {
            super(itemView);
            date = itemView.findViewById(R.id.dateText);
            time = itemView.findViewById(R.id.timeText);
            filial = itemView.findViewById(R.id.filialText);
            service = itemView.findViewById(R.id.serviceText);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_record_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Records record = records.get(position);

        holder.date.setText(record.getDate());
        holder.time.setText(record.getTime());
        holder.filial.setText(record.getFilial());
        holder.service.setText(record.getService());
    }

    @Override
    public int getItemCount() {
        return records.size();
    }
}
