package com.example.mfcfuture;

import java.util.ArrayList;

public class RecordStorage {

    public static ArrayList<Records> recordList = new ArrayList<>();

}
