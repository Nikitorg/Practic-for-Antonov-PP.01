package com.example.mfcfuture;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    EditText etFullName, etPhoneNumber, etPassword1, etPassword2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            setContentView(R.layout.activity_profile);

            User user = AutoizationActivity.currentUser;

            etFullName = findViewById(R.id.etFullName);
            etPhoneNumber = findViewById(R.id.etPhone);
            etPassword1 = findViewById(R.id.etPassword1);
            etPassword2 = findViewById(R.id.etPassword2);
            LinearLayout passwordButtonsLayout = findViewById(R.id.passwordButtonsLayout);

            etFullName.setText(user.getFullName());
            etPhoneNumber.setText(user.getNumberPhone());

            Button cancelPassword = findViewById(R.id.cancelPassword);
            Button backButton = findViewById(R.id.backButton);
            Button switchPassword = findViewById(R.id.switchPassword);
            Button historyButton = findViewById(R.id.historyButton);
            Button changePassword = findViewById(R.id.changePassword);

            // Назад
            backButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });

            historyButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(ProfileActivity.this, HistoryRecords.class);
                    startActivity(intent);
                }
            });

            // Отмена смены пароля
            cancelPassword.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (etPassword1.getVisibility() == View.GONE) {
                        etPassword1.setVisibility(View.VISIBLE);
                        etPassword2.setVisibility(View.VISIBLE);
                        passwordButtonsLayout.setVisibility(View.VISIBLE);
                    } else {
                        etPassword1.setVisibility(View.GONE);
                        etPassword2.setVisibility(View.GONE);
                        passwordButtonsLayout.setVisibility(View.GONE);
                    }
                }
            });

            // Смена пароля (показ полей)
            switchPassword.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (etPassword1.getVisibility() == View.GONE) {
                        etPassword1.setVisibility(View.VISIBLE);
                        etPassword2.setVisibility(View.VISIBLE);
                        passwordButtonsLayout.setVisibility(View.VISIBLE);
                    } else {
                        etPassword1.setVisibility(View.GONE);
                        etPassword2.setVisibility(View.GONE);
                        passwordButtonsLayout.setVisibility(View.GONE);
                    }
                }
            });

            // Подтверждение смены пароля
            changePassword.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String pass1 = etPassword1.getText().toString();
                    String pass2 = etPassword2.getText().toString();

                    if (!pass1.isEmpty() && !pass2.isEmpty()) {
                        if (pass1.equals(pass2)) {
                            if (!pass1.equals(user.getPassword())) {
                                AutoizationActivity.currentUser.setPassword(pass1);
                                Toast.makeText(ProfileActivity.this,
                                        "Пароль успешно изменен!",
                                        Toast.LENGTH_SHORT).show();
                                        etPassword1.setVisibility(View.GONE);
                                        etPassword2.setVisibility(View.GONE);
                                        passwordButtonsLayout.setVisibility(View.GONE);
                                        etPassword1.setText("");
                                        etPassword1.setText("");
                            } else {
                                Toast.makeText(ProfileActivity.this,
                                        "Пароль не должен совпадать со старым!",
                                        Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(ProfileActivity.this,
                                    "Пароли не совпадают!",
                                    Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(ProfileActivity.this,
                                "Заполните все поля!",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(ProfileActivity.this,
                    "Произошла ошибка: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }
}
