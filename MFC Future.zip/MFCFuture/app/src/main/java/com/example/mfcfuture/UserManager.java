package com.example.mfcfuture;

import java.util.ArrayList;
import java.util.List;

public class UserManager {

    private static final List<User> users = new ArrayList<>();

    public static boolean register(User user) {
        for (User u : users) {
            if (u.getLogin().equals(user.getLogin())) {
                return false;
            }
        }
        users.add(user);
        return true;
    }

    public static User login(String login, String password) {
        for (User user : users) {
            if (user.getLogin().equals(login) &&
                    user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }

    public static List<User> getUsers() {
        return users;
    }
}
