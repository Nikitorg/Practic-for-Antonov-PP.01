package com.example.mfcfuture;

public class User {
    private String fullName;
    private String numberPhone;
    private String login;
    private String password;

    public User(String fullName, String numberPhone, String login, String password) {
        this.fullName = fullName;
        this.numberPhone = numberPhone;
        this.login = login;
        this.password = password;
    }

    public String getFullName() {
        return fullName;
    }

    public String getNumberPhone() {
        return numberPhone;
    }

    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
